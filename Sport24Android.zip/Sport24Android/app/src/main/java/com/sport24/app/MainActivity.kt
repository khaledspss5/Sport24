package com.sport24.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101B2D)
private val Green = Color(0xFF19B56B)
private val Page = Color(0xFFF3F5F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Sport24App() }
    }
}

data class Match(
    val league: String,
    val home: String,
    val away: String,
    val score: String,
    val time: String,
    val live: Boolean = false
)

private val demoMatches = listOf(
    Match("الدوري الإنجليزي", "مانشستر سيتي", "ليفربول", "2 - 1", "مباشر 67'", true),
    Match("الدوري الإسباني", "ريال مدريد", "برشلونة", "—", "21:00"),
    Match("الدوري الإيطالي", "إنتر ميلان", "ميلان", "—", "غداً 20:45")
)

@Composable
fun Sport24App() {
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    val tabs = listOf("الرئيسية", "المباريات", "الأخبار", "الترتيب")
    val icons = listOf(Icons.Default.Home, Icons.Default.SportsSoccer, Icons.Default.Article, Icons.Default.Leaderboard)

    Scaffold(
        containerColor = Page,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Sport24", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text("كل أخبار كرة القدم في مكان واحد", color = Color(0xFFB9C6D8), fontSize = 12.sp)
                }
                Icon(Icons.Default.Notifications, contentDescription = "الإشعارات", tint = Color.White)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(icons[index], contentDescription = tab) },
                        label = { Text(tab) }
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 18.dp, bottom = 20.dp)
        ) {
            item {
                Text(
                    when (selectedTab) {
                        "المباريات" -> "المباريات"
                        "الأخبار" -> "آخر الأخبار"
                        "الترتيب" -> "ترتيب الدوريات"
                        else -> "مرحباً بك في Sport24 ⚽"
                    },
                    color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold
                )
            }
            when (selectedTab) {
                "الأخبار" -> {
                    item { InfoCard("أخبار كرة القدم", "هنا ستظهر آخر أخبار الأندية واللاعبين عند ربط مصدر الأخبار.") }
                    item { InfoCard("انتقالات اللاعبين", "تابع أخبار الانتقالات والتعاقدات الجديدة.") }
                }
                "الترتيب" -> {
                    item { InfoCard("الدوري الإنجليزي", "1. فريق تجريبي — 75 نقطة\n2. فريق تجريبي — 68 نقطة\n\nسيتم ربط الترتيب ببيانات حقيقية لاحقاً.") }
                    item { InfoCard("الدوري الإسباني", "جدول ترتيب تجريبي — أضف مصدر البيانات لعرض الترتيب المباشر.") }
                }
                else -> {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("المباريات", "12", Modifier.weight(1f))
                            StatCard("مباشر الآن", "3", Modifier.weight(1f))
                            StatCard("الدوريات", "5", Modifier.weight(1f))
                        }
                    }
                    item { Text("أبرز المباريات", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    items(demoMatches) { match -> MatchCard(match) }
                    item { InfoCard("ملاحظة", "هذه بيانات تجريبية للواجهة فقط، وليست نتائج مباشرة. سنربط التطبيق بواجهة بيانات كرة قدم في الخطوة التالية.") }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Color.DarkGray, fontSize = 11.sp)
        }
    }
}

@Composable
fun MatchCard(match: Match) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(match.league, color = Color.Gray, fontSize = 12.sp)
                Text(match.time, color = if (match.live) Green else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(match.home, color = Navy, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(match.score, color = Navy, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text(match.away, color = Navy, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(body, color = Color.DarkGray, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}
